# Cómo publicar tu sitio en GitHub Pages

**Archivos incluidos:**
- `index.html`
- `Ailenoxxan-logo.png`
- `banner-avon-natura.png`

## 1) Crear cuenta en GitHub
- https://github.com (si no tenés, creá una cuenta pública).

## 2) Crear un repositorio nuevo
- Botón **New**.
- Nombre sugerido: `pagina-ailenoxxan` (o el que prefieras).
- Visibilidad: **Public**.
- Crear repo.

## 3) Subir los archivos
- Dentro del repo, clic **Add file → Upload files**.
- Arrastrá `index.html`, `Ailenoxxan-logo.png` y `banner-avon-natura.png`.
- Clic **Commit changes** para guardar.

## 4) Activar GitHub Pages
- Ir a **Settings → Pages**.
- En **Source**, elegí **Deploy from a branch**.
- Branch: `main` — Folder: **/root**.
- Guardar. En 1–2 min tendrás tu sitio online.

La URL será:
`https://TU_USUARIO.github.io/NOMBRE_DEL_REPO/`

> Tip: Si llamás al repo `TU_USUARIO.github.io`, tu sitio quedará en la raíz:  
> `https://TU_USUARIO.github.io`

## 5) Actualizar después
- Si cambiás imágenes o el HTML, solo subí la nueva versión (commit).
- GitHub Pages se actualiza automáticamente.

## 6) Opcional: SEO
- Podés agregar tu sitio en **Google Search Console** para que Google lo indexe más rápido.

¡Éxitos! 💖
